package BST;

import binary_tree.BTNode;

class BST_rec{
	BTNode root;
	
	public BST_rec(){}
}