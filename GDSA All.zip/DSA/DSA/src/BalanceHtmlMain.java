
public class BalanceHtmlMain {
	public static void main(String[] args) {
		//BalanceHtml b=new BalanceHtml();
		//b.checkExp("<html><p></p></html>");
		String str="<html><p></p></html>";
		//System.out.println(str.s);
	}

}
