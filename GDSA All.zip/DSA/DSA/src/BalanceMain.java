
public class BalanceMain {
	public static void main(String[] args) {
		BalanceExp b=new BalanceExp();
		b.checkExp("[2*3({5+4)}]");
		
	}

}
