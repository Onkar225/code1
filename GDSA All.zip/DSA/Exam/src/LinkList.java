
import java.util.Scanner;

import Sorting.EmpNode;

public class LinkList {
	private IntNode head;
	Scanner s = new Scanner(System.in);

	public LinkList() {
	}

	public IntNode getHead() {
		return head;
	}

	public void setHead(IntNode head) {
		this.head = head;
	}

	// even odd list
	public IntNode evenOdd() {
		IntNode head2 = null, itr = head;
		if (itr == null) {
			System.out.println("List empty");
			return null;
		}
		while (itr != null) {

			IntNode new_node = new IntNode(itr.getData());
			if ((new_node.getData()) % 2 == 0) {
				System.out.println("even " + new_node.getData());

				if (head2 == null) {
					head2 = new_node;
				}
				new_node.setNext(head2);
				head2 = new_node;

			} else {
				System.out.println("odd " + new_node.getData());

				if (head2 == null) {
					head2 = new_node;
				} else {
					IntNode it = head2;
					while (it.getNext() != null)
						it = it.getNext();
					it.setNext(new_node);
				}
			}
			itr = itr.getNext();
		}

		return head2;
	}

	// sorting list bubble
	public void bubble_sort(IntNode head) {
		int i, j, temp;
		int size = count();
		IntNode itr = head;
		System.out.println(" count " + size);
		for (i = size - 1; i >= 0; i--) {
			for (j = 0; j < i; j++) {
				if (itr.getData() > itr.getNext().getData()) {
					temp = itr.getData();
					itr.setData(itr.getNext().getData());
					itr.getNext().setData(temp);
				}
				itr = itr.getNext();
			}
			itr = head;
		}
	}

	// swap adjecent node
	public void swap_adj() {
		if (head == null) {
			System.out.println("Empty list");
			return;
		}
		IntNode itr = head;
		while (itr != null) {

			if (itr.getNext() != null) {
				int temp;
				temp = itr.getData();
				itr.setData(itr.getNext().getData());
				itr.getNext().setData(temp);
				itr = itr.getNext().getNext();

			} else
				itr = itr.getNext();
		}
	}

	// reverse display
	public void display_reverse(IntNode itr) {
		if (itr == null)
			return;
		display_reverse(itr.getNext());
		System.out.print(itr.getData() + " ");

	}

	// reverse using 3 variable
	public void reverse() {
		IntNode prev = null, next, itr = head;
		if (head == null) {
			System.out.println("empty");
			return;
		}
		while (itr != null) {
			next = itr.getNext();
			itr.setNext(prev);
			prev = itr;
			itr = next;
		}
		head = prev;
	}

	// reverse using recursion
	public void reverse_rec() {
		head = reverseR(head);
	}

	public IntNode reverseR(IntNode head) {
		IntNode temp = null, itr = head;

		if (itr.getNext() == null)
			return itr;
		temp = reverseR(itr.getNext());
		itr.getNext().setNext(itr);
		if (itr == head)
			itr.setNext(null);
		return temp;

	}

	// spilt list into two list
	public void split(int value) {
		if (head == null) {
			System.out.println("empty list");
			return;
		}
		IntNode itr = head;
		IntNode head2;
		while (itr.getNext().getData() != value)
			itr = itr.getNext();
		head2 = itr.getNext();
		itr.setNext(null);
		System.out.println("LIST 1\n");
		show(head);
		System.out.println("LIST 2");
		show(head2);
	}

	// display list by passing head
	public void show(IntNode head) {
		while (head != null) {
			System.out.println(" " + head.getData());
			head = head.getNext();
		}
	}

	// display alternative
	public void displayAL() {
		if (head == null) {
			System.out.println("Empty list");
			return;
		}
		IntNode itr = head;
		while (itr != null) {
			System.out.println(itr.getData() + " ");
			if (itr.getNext() != null)
				itr = itr.getNext().getNext();
			else
				itr = itr.getNext();
		}
	}

	// delete alternative
	public void delete_alt() {
		if (head == null) {
			System.out.println("Empty list");
			return;
		}
		int i = 1;
		IntNode itr = head;
		while (itr != null) {
			System.out.println(deleteByPos(i) + " ");

			if (itr.getNext() != null) {
				itr = itr.getNext().getNext();
				i = i + 2;
			} else {
				itr = itr.getNext();
				i++;
			}
		}
	}

	// create list
	public void createList(int n) {
		int data;
		for (int i = 1; i <= n; i++) {
			System.out.println("enter value" + i + " node");
			data = s.nextInt();
			insertLast(data);
		}
	}

	// insert Last
	public void insertLast(int data) {
		IntNode new_node = new IntNode(data);
		if (head == null) {
			head = new_node;
			return;
		}
		IntNode itr = head;
		while (itr.getNext() != null)
			itr = itr.getNext();
		itr.setNext(new_node);
		return;
	}

	// insert first
	public void insertFirst(int data) {
		IntNode new_node = new IntNode(data);
		if (head == null) {
			head = new_node;
			return;
		}
		new_node.setNext(head);
		head = new_node;
		return;
	}

	// insert First
	public int deleteFirst() {
		int d = -999;
		IntNode del;
		if (head == null)
			return d;
		del = head;
		head = head.getNext();
		del.setNext(null);
		d = del.getData();
		del = null;
		return d;
	}

	// delete Last
	public int deleteLast() {
		int d = -999;
		IntNode del;
		if (head == null)
			return d;
		IntNode itr = head;
		while (itr.getNext().getNext() != null)
			itr = itr.getNext();
		del = itr.getNext();
		d = del.getData();
		itr.setNext(null);
		del = null;
		return d;
	}

	// delete By pos
	public int deleteByPos(int pos) {
		int d = -999;
		IntNode del = null;
		if (head == null)
			return d;
		IntNode itr = head;
		for (int i = 1; i < pos - 1 && itr.getNext() != null; i++, itr = itr.getNext())
			;
		del = itr.getNext();
		d = del.getData();
		itr.setNext(itr.getNext().getNext());
		return d;
	}

	// delete By pos end of list
	public int deleteByPosL(int pos) {
		int posl = count();
		pos = posl - pos;
		pos++;
		int d = -999;
		IntNode del = null;
		if (head == null)
			return d;
		IntNode itr = head;
		for (int i = 1; i < pos - 1 && itr.getNext() != null; i++, itr = itr.getNext())
			;
		del = itr.getNext();
		d = del.getData();
		itr.setNext(itr.getNext().getNext());
		return d;
	}

	// count nodes
	public int count() {
		int i = 0;
		IntNode itr = head;
		while (itr != null) {
			i++;
			itr = itr.getNext();
		}
		return i;
	}

	// display list using toString
	public String toString() {
		String str = "List : ";
		IntNode itr = head;
		while (itr != null) {
			str = str + "-> " + itr.getData() + " ";
			itr = itr.getNext();
		}
		return str;
	}

}
