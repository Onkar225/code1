import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		LinkList l=new LinkList();
		Scanner s=new Scanner(System.in);
		int ch=0,data=0;
		do {
			System.out.println("\n\t**********LinkList Operations ************");
			System.out.println("1.Create List");
			System.out.println("2.Insert First ");
			System.out.println("3.Insert Last ");
			System.out.println("4.count Last ");
			System.out.println("5.Delete First ");
			System.out.println("6.Delete Last ");
			System.out.println("7.Delete ByPOS  ");
			System.out.println("8.Delete ByPOS end ");
			System.out.println("9.Display alternate ");
			System.out.println("10.Display List ");
			System.out.println("11.delete Alternative");
			System.out.println("12.split by value");
			System.out.println("13. recursive reverse");
			System.out.println("14. non-rec reverse");
			System.out.println("15.display reverse byrec");
			System.out.println("16.make list even then odd ");
			System.out.println("17.addition of two list");
			System.out.println("18.Sort list Using BUBBLE SORT");
			System.out.println("19.swap adjecent node");
			System.out.println("20.Exit");
			System.out.println("Enter choice");
			ch=s.nextInt();
			if(ch>1 && ch<5)
			{
				System.out.println("Enter data");
				data=s.nextInt();
			}
			switch(ch)
			{
			case 1: 
				System.out.println("Enter size");
				data=s.nextInt();
				l.createList(data);
					break;
			case 2: 
				l.insertFirst(data);
				break;
			case 3: 
				l.insertLast(data);
				break;
			case 4: 
				System.out.println(l.count()); 
				break;
			case 5: 
				int d=l.deleteFirst();
				if(d==-999)
					System.out.println("List is Empty");
				else
					System.out.println(d+" Node remove");
				break;
			case 6: 
				 d=l.deleteLast();
				if(d==-999)
					System.out.println("List is Empty");
				else
					System.out.println(d+" Node remove");
				break;
			case 7: 
				System.out.println("enter pos");
				int pos=s.nextInt();
				 d=l.deleteByPos(pos);
				if(d==-999)
					System.out.println("List is Empty");
				else
					System.out.println(d+" Node remove");
				break;
			case 8: 
				System.out.println("enter pos");
				 pos=s.nextInt();
				 d=l.deleteByPosL(pos);
				if(d==-999)
					System.out.println("List is Empty");
				else
					System.out.println(d+" Node remove");
				break;
			case 9: 
				l.displayAL();
				break;
			case 10: 
				System.out.println(l);
				break;
			case 11: 
				l.delete_alt();
				break;
			case 12: 
				System.out.println("enter value");
				 pos=s.nextInt();
				 l.split(pos);
				break;
			case 13: 
				System.out.println("After reverse");
				 l.reverse_rec();
				 System.out.println(l);
				break;
			case 14: 
				System.out.println("After reverse");
				 l.reverse();
				 System.out.println(l);
				break;
			case 15: 
				System.out.println("display reverse");
				 l.display_reverse(l.getHead());
				break;
			case 16: 
				System.out.println(l);
				System.out.println("Even then odd");
				 l.setHead(l.evenOdd());
				 System.out.println(l);
				break;
			
			case 18: 
				System.out.println("After sort");
				 l.bubble_sort(l.getHead());
				 System.out.println(l);
				break;
			case 19: 
				System.out.println("After swap");
				 l.swap_adj();
				 System.out.println(l);
				break;
			}
		}while(ch!=20);
	}

}
