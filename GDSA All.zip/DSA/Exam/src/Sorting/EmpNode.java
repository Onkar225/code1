package Sorting;

public class EmpNode {
	private Employee data;
	private EmpNode next;
	
	public EmpNode() {}
	public EmpNode(Employee e){	data=e;}
	public Employee getData() {
		return data;
	}
	public void setData(Employee data) {
		this.data = data;
	}
	public EmpNode getNext() {
		return next;
	}
	public void setNext(EmpNode next) {
		this.next = next;
	}
	

}
