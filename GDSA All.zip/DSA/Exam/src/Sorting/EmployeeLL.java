package Sorting;

import java.util.Scanner;

public class EmployeeLL {
	private EmpNode head;

	public EmployeeLL() {}
	public EmpNode getHead() {
		return head;
	}

	public void setHead(EmpNode head) {
		this.head = head;
	}
	public void insertLast(Employee e) {
		EmpNode new_node=new EmpNode(e);
		if(head==null)
		{
			head=new_node;
			return;
		}
		EmpNode itr=head;
		while(itr.getNext()!=null)
			itr=itr.getNext();
		itr.setNext(new_node);
		return;
	}
	public void display()
	{
		String str="List :";
		if(head==null)
		{
			System.out.println("Empty list :");
			return ;
		}
		EmpNode itr=head;
		while(itr!=null)
		{
			
			System.out.println(itr.getData()+" ");
			itr=itr.getNext();
		}
	}
	public void display_reverse(EmpNode e)
	{
		if(e==null) return;
		display_reverse(e.getNext());
		System.out.println(e.getData()+" ");
	}

	/*
	 * public void reverse_rec(EmpNode e) { if(e==null) return null;
	 * display_reverse(e.getNext()); System.out.println(e.getData()+" "); }
	 */
	public void reverse() {
		EmpNode itr,prev=null,next;
		itr=head;
		while(itr!=null)
		{
			next=itr.getNext();
			itr.setNext(prev);
			prev=itr; 
			itr=next;	
		}
		head=prev;
	}
	public static void main(String[] args) {
		EmployeeLL l=new EmployeeLL();
		Scanner s=new Scanner(System.in);
		System.out.println("enter size");
		int size=s.nextInt();
		for(int i=0;i<size;i++)
		{
			System.out.println("enter id ");
			int id=s.nextInt();
			System.out.println("enter name ");
			String name=s.next();
			System.out.println("enter salary ");
			double sal=s.nextDouble();
			l.insertLast(new Employee(id,name,sal));	
		}
		l.display();
		System.out.println("display reverse\n");
		l.display_reverse(l.getHead());
		System.out.println(" reverse\n");
		l.reverse();
		l.display();
	}
}
