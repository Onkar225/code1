package Sorting;

import java.util.ArrayList;

public class SortBySalary {
	
	public static void bubble_sort(Employee []emp)
	{
		int i,j,flag;
		double sal;
		for(i=emp.length-1;i>0;i--)
		{
			flag=0;
			for(j=0;j<i;j++)
			{
				if(emp[j].getSalary()>emp[j+1].getSalary())
				{
					Employee temp=emp[j];
					emp[j]=emp[j+1];
					emp[j+1]=temp;
					flag=1;
				}
			}
			if(flag==0)
				break;
		}
	}
	public static void main(String[] args) {
		Employee e[]=new Employee[6];
		
		e[0]=new Employee(1,"anil",60000.00);
		e[1]=new Employee(2,"swaraj",90000.00);
		e[2]=new Employee(3,"pranav",4000.00);
		e[3]=new Employee(4,"anshul",70000.00);
		e[4]=new Employee(5,"tripur",50000.00);
		e[5]=new Employee(6,"sagar",10000.00);
		System.out.println("orignal list");
		for(Employee ee:e)
			System.out.println(ee);
		System.out.println("Sorted list");
		bubble_sort(e);
		for(Employee ee:e)
			System.out.println(ee);
	}

}
